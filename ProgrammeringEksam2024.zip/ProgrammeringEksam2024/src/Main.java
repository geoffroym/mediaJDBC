import java.io.FileNotFoundException;
import java.sql.SQLException;


public class Main {
    public static void main(String[] args) throws SQLException, FileNotFoundException {
        new Program();
        /*FoundService funnService = new FoundService();
        funnService.addPersonFromFile("funn.txt");
        funnService.addMuseumFromFile("funn.txt");*/

    }
}